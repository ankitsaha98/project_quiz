<?php
$link=mysqli_connect('localhost','bbmediao_crypt','Cryptadmin@981119','bbmediao_cryptpythonblog');
    if(mysqli_connect_error())
    {
        die(mysqli_connect_error());
    }


?>