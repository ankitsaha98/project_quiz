<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Insert_q extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function insert_data_into_table() {
        $data = array(
            'question' => $_POST['ques'],
            'option1' => $_POST['op1'],
            'option2' => $_POST['op2'],
            'option3' => $_POST['op3'],
            'option4' => $_POST['op4'],
            'correct' => $_POST['cop'],
            'category' => $_POST['category']
        );
        $query = $this->db->insert('questions', $data);
        
    }

}
