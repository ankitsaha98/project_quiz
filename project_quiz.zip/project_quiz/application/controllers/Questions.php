<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Questions extends CI_Controller {
    public function index()
    {
        $this->load->view('new_questions.php');
    }
    public function insert_questions() {
        $this->load->model('insert_q');
        $this->insert_q->insert_data_into_table();
        
    }
}

