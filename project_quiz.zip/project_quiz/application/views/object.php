class Smartphone
{
	private $size;
	private $camera;
	public function __construct($size,$camera)
	{
		$this -> size = $size;//refers to that object on which that fn is called in which $this is present
		$this -> camera=$camera;
	}
	public function make_call(){

	}
	public function take_picture(){

	}
}
//end of class1
//st of class2

$my_phone = new Smartphone("5 inch","8mp")
$my_phone -> take_picture();